from django.apps import AppConfig


class KkConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kk'
