from django.shortcuts import render, redirect
import smtplib, ssl
from django.contrib.auth import logout,authenticate,login
port = 465  
Password = "qirxxomxmcunyyuq"
context = ssl.create_default_context()
message = """From: From Person <from@example.com>
To: To Person <to@example.com>
Subject: you are successfull loged in"""
# Create your views here.
def index(request):
    return render(request, 'login.html')

def loginUser(request):
    if request.method=="POST":
        username=request.POST.get('username')
        password=request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request,user)
            with smtplib.SMTP_SSL("smtp.gmail.com", port, context=context) as server:
                server.login("karankwatra978@gmail.com", Password)
                server.sendmail("karankwatra978@gmail.com", "geeta.mind@gmail.com", message)
            return redirect('fileupload/upload/')
        else:
         
            return render(request, 'login.html')
    return render(request, 'login.html')

def logoutUser(request):
    logout(request)
    return redirect("/login")