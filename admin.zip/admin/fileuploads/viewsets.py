from rest_framework import viewsets
from . import models
from . import serializers
from .custompermissions import MyPermission
from rest_framework.authentication import SessionAuthentication


class EmployeeViewSet(viewsets.ModelViewSet):
    authentication_classes=[SessionAuthentication]
    permission_classes=[MyPermission]
    queryset=models.UploadedFile.objects.all()
    serializer_class=serializers.UploadedFileSerializer