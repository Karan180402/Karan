from rest_framework.permissions import BasePermission

class MyPermission(BasePermission):
    def has_permission(self,request,view):
        if request.user.is_superuser:
            return True
        if request.user.is_authenticated:
            if request.method=='GET':
                return False
        else:
            return False