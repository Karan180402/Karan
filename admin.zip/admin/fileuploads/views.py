from django.shortcuts import render, redirect
import smtplib, ssl
from .forms import FileUploadForm
from .models import UploadedFile
from django.contrib.auth import logout,authenticate,login
port = 465  
password = "qirxxomxmcunyyuq"
context = ssl.create_default_context()
message = """From: From Person <from@example.com>
To: To Person <to@example.com>
Subject: Email related to Account Payment instruction"""

def upload_file(request):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('file_list')
    else:
        form = FileUploadForm()
    return render(request, 'upload_file.html', {'form': form})

def file_list(request):
    files = UploadedFile.objects.all()
    return render(request, 'list.html', {'files': files})

def index(request):
    return render(request, 'index.html')

def loginUser(request):
    if request.method=="POST":
        username=request.POST.get('username')
        password=request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
           
            login(request,user)
            with smtplib.SMTP_SSL("smtp.gmail.com", port, context=context) as server:
                 server.login("karankwatra978@gmail.com", password)
                 server.sendmail("karankwatra978@gmail.com", "accountholder@---.com", message)
                 print('the message is sent that you have successfully login')
            return redirect("/")
        else:
         
            return render(request, 'login.html')
    return render(request, 'login.html')

def logoutUser(request):
    logout(request)
    return redirect("/login")