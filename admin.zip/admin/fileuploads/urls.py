from django.urls import path
from .views import upload_file, file_list,index,loginUser,logoutUser

urlpatterns = [
    path('upload/', upload_file, name='upload_file'),
    path('files/', file_list, name='file_list'),
    path('', index,name="home"),
    path('login', loginUser,name="login"),
    path('logout', logoutUser,name="logout"),
]

